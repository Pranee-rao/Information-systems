#Drop existing tables to ensure clean slate

DROP TABLE IF EXISTS Issues;
DROP TABLE IF EXISTS Manager_Comments;
DROP TABLE IF EXISTS Task;
DROP TABLE IF EXISTS Employee_Assignments;
DROP TABLE IF EXISTS Shift;
DROP TABLE IF EXISTS Shift_Pattern;
DROP TABLE IF EXISTS Manager;
DROP TABLE IF EXISTS Employee;

#Creating tables to store employee, manager, shift, task, comments, and issues information
CREATE TABLE Employee(
EmployeeID int NOT NULL AUTO_INCREMENT,
FirstName varchar(25),
LastName varchar(25),
HireDate Date,
PRIMARY KEY (EmployeeID));

CREATE TABLE Manager(
ManagerID int NOT NULL,
EmployeeID INT NULL AUTO_INCREMENT,
Managementlevel varchar(25),
PRIMARY KEY (ManagerID),
foreign key (EmployeeID) references Employee(EmployeeID));

CREATE TABLE Shift_Pattern(
PatternID int NOT NULL AUTO_INCREMENT,
Patterntype varchar(25),
Description varchar(250),
PRIMARY KEY (PatternID));

CREATE TABLE Shift(
ShiftID int NOT NULL AUTO_INCREMENT,
Date DATE,
Starttime datetime,
Endtime datetime,
Duration float,
PatternID INT NOT NULL,
EmployeeID INT NOT NULL,
PRIMARY KEY (ShiftID),
foreign key (PatternID) references Shift_Pattern(PatternID),
foreign key (EmployeeID) references Employee(EmployeeID)) ;


CREATE TABLE Employee_Assignments(
AssignmentID int,
ManagerID int NOT NULL AUTO_INCREMENT,
ShiftID int ,
PRIMARY KEY (AssignmentID),
foreign key (ManagerID) references Manager(ManagerID),
foreign key (ShiftID) references Shift(ShiftID));

CREATE TABLE Task(
TaskID int NOT NULL AUTO_INCREMENT,
Description varchar(250),
AssignmentID int,
PRIMARY KEY (TaskID),
foreign key (AssignmentID) references Employee_Assignments(AssignmentID));

CREATE TABLE Manager_Comments(
CommentID int not null,
CommentText varchar(500),
AssignmentID int NULL AUTO_INCREMENT,
PRIMARY KEY (CommentID),
foreign key (AssignmentID) references Employee_Assignments(AssignmentID));

CREATE TABLE Issues(
IssueID int,
Description varchar(250),
IssueStatus Varchar(25),
AssignmentID INT NOT NULL AUTO_INCREMENT,
PRIMARY KEY (IssueID),
foreign key (AssignmentID) references Employee_Assignments(AssignmentID));

# Inserting employee data into the Employee table

INSERT INTO Employee (EmployeeID, FirstName, LastName, HireDate) VALUES
(1001, 'John', 'Smith', '2020-01-15'),
(1002, 'Emily', 'Johnson', '2019-07-20'),
(1003, 'Michael', 'Williams', '2021-03-10'),
(1004, 'Sarah', 'Brown', '2020-11-05'),
(1005, 'James', 'Jones', '2018-09-30'),
(1006, 'Jennifer', 'Davis', '2019-04-25'),
(1007, 'David', 'Miller', '2020-02-18'),
(1008, 'Jessica', 'Wilson', '2019-08-12'),
(1009, 'Daniel', 'Taylor', '2021-01-07'),
(1010, 'Amanda', 'Anderson', '2019-05-22'),
(1011, 'Matthew', 'Thomas', '2020-12-30'),
(1012, 'Lauren', 'Jackson', '2018-10-10'),
(1013, 'Christopher', 'White', '2019-09-14'),
(1014, 'Ashley', 'Harris', '2020-04-03'),
(1015, 'Ryan', 'Martin', '2021-02-28'),
(1016, 'Brittany', 'Thompson', '2018-06-17'),
(1017, 'Andrew', 'Garcia', '2019-11-09'),
(1018, 'Megan', 'Martinez', '2020-07-04'),
(1019, 'Justin', 'Robinson', '2021-04-12'),
(1020, 'Kayla', 'Clark', '2019-03-05'),
(1021, 'Brandon', 'Lewis', '2018-08-01'),
(1022, 'Stephanie', 'Lee', '2020-06-23'),
(1023, 'Kevin', 'Walker', '2019-10-17'),
(1024, 'Hannah', 'Hall', '2021-05-19'),
(1025, 'Nicholas', 'Young', '2018-11-28'),
(1026, 'Samantha', 'Allen', '2019-12-25'),
(1027, 'Joseph', 'Scott', '2020-09-08'),
(1028, 'Rachel', 'Green', '2018-07-02'),
(1029, 'Tyler', 'Adams', '2019-02-14'),
(1030, 'Alexis', 'Baker', '2020-08-06'),
(1031, 'Caleb', 'Carter', '2021-06-13'),
(1032, 'Olivia', 'Cook', '2018-12-31'),
(1033, 'Dylan', 'Edwards', '2019-06-26'),
(1034, 'Grace', 'Evans', '2020-03-15'),
(1035, 'Logan', 'Flores', '2021-01-28'),
(1036, 'Emma', 'Gonzalez', '2018-09-10'),
(1037, 'Nathan', 'Hill', '2019-05-03'),
(1038, 'Madison', 'Howard', '2020-11-24'),
(1039, 'Ethan', 'King', '2018-08-18'),
(1040, 'Isabella', 'Lopez', '2019-10-01'),
(1041, 'Liam', 'Morris', '2020-04-20'),
(1042, 'Abigail', 'Nelson', '2021-02-15'),
(1043, 'Mason', 'Perez', '2018-06-09'),
(1044, 'Sophia', 'Rivera', '2019-07-14'),
(1045, 'Aiden', 'Sanchez', '2020-01-25'),
(1046, 'Chloe', 'Stewart', '2019-12-04'),
(1047, 'Elijah', 'Torres', '2018-07-29'),
(1048, 'Evelyn', 'Turner', '2019-03-22'),
(1049, 'Gabriel', 'Ward', '2020-08-15'),
(1050, 'Harper', 'Wood', '2021-04-08');

# Insert manager data into the Manager table

INSERT INTO Manager (ManagerID, EmployeeID, ManagementLevel) VALUES
(101, 1001, 'Senior Manager'),
(102, 1002, 'Assistant Manager'),
(103, 1003, 'Junior Manager'),
(104, 1004, 'Senior Manager'),
(105, 1005, 'Assistant Manager'),
(106, 1006, 'Junior Manager'),
(107, 1007, 'Senior Manager'),
(108, 1008, 'Assistant Manager'),
(109, 1009, 'Junior Manager'),
(110, 1010, 'Senior Manager'),
(111, 1011, 'Assistant Manager'),
(112, 1012, 'Junior Manager'),
(113, 1013, 'Senior Manager'),
(114, 1014, 'Assistant Manager'),
(115, 1015, 'Junior Manager'),
(116, 1016, 'Senior Manager'),
(117, 1017, 'Assistant Manager'),
(118, 1018, 'Junior Manager'),
(119, 1019, 'Senior Manager'),
(120, 1020, 'Assistant Manager'),
(121, 1021, 'Junior Manager'),
(122, 1022, 'Senior Manager'),
(123, 1023, 'Assistant Manager'),
(124, 1024, 'Junior Manager'),
(125, 1025, 'Senior Manager'),
(126, 1026, 'Assistant Manager'),
(127, 1027, 'Junior Manager'),
(128, 1028, 'Senior Manager'),
(129, 1029, 'Assistant Manager'),
(130, 1030, 'Junior Manager');

# Insert shift patterns into the Shift_Pattern table

INSERT INTO Shift_Pattern (PatternID, Patterntype, Description)
VALUES 
(1, 'Day Shift', 'Regular day shift pattern'),
(2, 'Night Shift', 'Regular night shift pattern'),
(3, 'Weekend Shift', 'Shift pattern for weekends'),
(4, 'Rotating Shift', 'Pattern rotates between day and night shifts'),
(5, '12-Hour Shift', '12-hour shift pattern'),
(6, '8-Hour Shift', 'Standard 8-hour shift pattern'),
(7, 'On-Call Shift', 'Shift for on-call employees'),
(8, 'Split Shift', 'Shift divided into multiple segments'),
(9, 'Fixed Shift', 'Fixed shift pattern with consistent hours'),
(10, 'Flexible Shift', 'Flexible shift pattern allowing variable hours'),
(11, 'Double Shift', 'Employee works two consecutive shifts'),
(12, 'Triple Shift', 'Employee works three consecutive shifts'),
(13, 'Irregular Shift', 'Shift pattern with irregular hours'),
(14, 'Part-Time Shift', 'Shift pattern for part-time employees'),
(15, 'Full-Time Shift', 'Shift pattern for full-time employees'),
(16, 'Seasonal Shift', 'Shift pattern adjusted for seasonal workload'),
(17, 'Emergency Shift', 'Shift pattern for emergency situations'),
(18, 'Remote Shift', 'Shift pattern for remote work'),
(19, 'Overtime Shift', 'Shift pattern with overtime hours'),
(20, 'Holiday Shift', 'Shift pattern for holidays'),
(21, 'Backup Shift', 'Backup shift pattern for replacement employees'),
(22, 'Continuous Shift', 'Shift pattern with continuous operation'),
(23, 'Intermittent Shift', 'Shift pattern with intermittent work periods'),
(24, 'Fixed Rotation Shift', 'Shift pattern with fixed rotation schedule'),
(25, 'Variable Rotation Shift', 'Shift pattern with variable rotation schedule'),
(26, 'Staggered Shift', 'Shift pattern with staggered start times'),
(27, 'Compressed Workweek', 'Shift pattern with fewer but longer workdays'),
(28, 'Flexible Workweek', 'Shift pattern allowing flexibility in workdays'),
(29, 'Standard Workweek', 'Shift pattern following standard workweek'),
(30, 'Custom Shift', 'Customized shift pattern based on specific needs');

# Insert shift data into the Shift table

INSERT INTO Shift (ShiftID, Date, StartTime, EndTime, Duration, PatternID, EmployeeID) VALUES
(201, '2024-03-17', '2024-03-17 08:00:00', '2024-03-17 12:00:00', 4, 1, 1001),
(202, '2024-03-17', '2024-03-17 12:00:00', '2024-03-17 16:00:00', 4, 2, 1002),
(203, '2024-03-17', '2024-03-17 16:00:00', '2024-03-17 20:00:00', 4, 3, 1003),
(204, '2024-03-17', '2024-03-17 08:00:00', '2024-03-17 12:00:00', 4, 1, 1004),
(205, '2024-03-17', '2024-03-17 12:00:00', '2024-03-17 16:00:00', 4, 2, 1005),
(206, '2024-03-17', '2024-03-17 16:00:00', '2024-03-17 20:00:00', 4, 3, 1006),
(207, '2024-03-17', '2024-03-17 08:00:00', '2024-03-17 12:00:00', 4, 1, 1007),
(208, '2024-03-17', '2024-03-17 12:00:00', '2024-03-17 16:00:00', 4, 2, 1008),
(209, '2024-03-17', '2024-03-17 16:00:00', '2024-03-17 20:00:00', 4, 3, 1009),
(210, '2024-03-17', '2024-03-17 08:00:00', '2024-03-17 12:00:00', 4, 1, 1010),
(211, '2024-03-17', '2024-03-17 12:00:00', '2024-03-17 16:00:00', 4, 2, 1011),
(212, '2024-03-17', '2024-03-17 16:00:00', '2024-03-17 20:00:00', 4, 3, 1012),
(213, '2024-03-17', '2024-03-17 08:00:00', '2024-03-17 12:00:00', 4, 1, 1013),
(214, '2024-03-17', '2024-03-17 12:00:00', '2024-03-17 16:00:00', 4, 2, 1014),
(215, '2024-03-17', '2024-03-17 16:00:00', '2024-03-17 20:00:00', 4, 3, 1015),
(216, '2024-03-17', '2024-03-17 08:00:00', '2024-03-17 12:00:00', 4, 1, 1016),
(217, '2024-03-17', '2024-03-17 12:00:00', '2024-03-17 16:00:00', 4, 2, 1017),
(218, '2024-03-17', '2024-03-17 16:00:00', '2024-03-17 20:00:00', 4, 3, 1018),
(219, '2024-03-17', '2024-03-17 08:00:00', '2024-03-17 12:00:00', 4, 1, 1019),
(220, '2024-03-17', '2024-03-17 12:00:00', '2024-03-17 16:00:00', 4, 2, 1020),
(221, '2024-03-17', '2024-03-17 16:00:00', '2024-03-17 20:00:00', 4, 3, 1021),
(222, '2024-03-17', '2024-03-17 08:00:00', '2024-03-17 12:00:00', 4, 1, 1022),
(223, '2024-03-17', '2024-03-17 12:00:00', '2024-03-17 16:00:00', 4, 2, 1023),
(224, '2024-03-17', '2024-03-17 16:00:00', '2024-03-17 20:00:00', 4, 3, 1024),
(225, '2024-03-17', '2024-03-17 08:00:00', '2024-03-17 12:00:00', 4, 1, 1025),
(226, '2024-03-17', '2024-03-17 12:00:00', '2024-03-17 16:00:00', 4, 2, 1026),
(227, '2024-03-17', '2024-03-17 16:00:00', '2024-03-17 20:00:00', 4, 3, 1027),
(228, '2024-03-17', '2024-03-17 08:00:00', '2024-03-17 12:00:00', 4, 1, 1028),
(229, '2024-03-17', '2024-03-17 12:00:00', '2024-03-17 16:00:00', 4, 2, 1029),
(230, '2024-03-17', '2024-03-17 16:00:00', '2024-03-17 20:00:00', 4, 3, 1030);

#Insert employee assignments data into the Employee_Assignments table

INSERT INTO Employee_Assignments (AssignmentID, ManagerID, ShiftID) VALUES
(1, 101, 201),
(2, 102, 202),
(3, 103, 203),
(4, 104, 204),
(5, 105, 205),
(6, 106, 206),
(7, 107, 207),
(8, 108, 208),
(9, 109, 209),
(10, 110, 210),
(11, 111, 211),
(12, 112, 212),
(13, 113, 213),
(14, 114, 214),
(15, 115, 215),
(16, 116, 216),
(17, 117, 217),
(18, 118, 218),
(19, 119, 219),
(20, 120, 220),
(21, 121, 221),
(22, 122, 222),
(23, 123, 223),
(24, 124, 224),
(25, 125, 225),
(26, 126, 226),
(27, 127, 227),
(28, 128, 228),
(29, 129, 229),
(30, 130, 230);

#Insert task information data into the Task table

INSERT INTO Task (TaskID, Description, AssignmentID) VALUES
(1, 'Prepare dining hall for breakfast service', 1),
(2, 'Check inventory levels of food supplies', 2),
(3, 'Set up dining stations for lunch', 3),
(4, 'Inspect kitchen equipment for safety', 4),
(5, 'Assist with meal preparation', 5),
(6, 'Serve meals to students and faculty', 6),
(7, 'Clean and sanitize dining tables', 7),
(8, 'Restock condiments and utensils', 8),
(9, 'Coordinate with kitchen staff for dinner menu', 9),
(10, 'Organize special events in the dining hall', 10),
(11, 'Handle customer inquiries and complaints', 11),
(12, 'Monitor food temperature and quality', 12),
(13, 'Train new dining hall employees', 13),
(14, 'Implement sustainability initiatives', 14),
(15, 'Update menu boards with daily specials', 15),
(16, 'Conduct health and safety inspections', 16),
(17, 'Plan themed dining nights', 17),
(18, 'Manage cashier transactions', 18),
(19, 'Coordinate with local vendors for fresh produce', 19),
(20, 'Promote dining services on social media', 20),
(21, 'Collaborate with nutritionists for menu planning', 21),
(22, 'Collect feedback from diners for improvement', 22),
(23, 'Attend staff meetings to discuss operations', 23),
(24, 'Schedule staff shifts and breaks', 24),
(25, 'Create employee recognition programs', 25),
(26, 'Organize team-building activities for staff', 26),
(27, 'Evaluate performance of dining hall operations', 27),
(28, 'Implement food waste reduction strategies', 28),
(29, 'Develop partnerships with local businesses', 29),
(30, 'Coordinate with campus events for catering services', 30);

#Insert manager comments data into the Manager_Comments table

INSERT INTO Manager_Comments (CommentID, CommentText, AssignmentID) VALUES
(1, 'Great job organizing breakfast service today!', 1),
(2, 'Please ensure we have enough vegetarian options available.', 2),
(3, 'Thank you for your hard work setting up the dining stations.', 3),
(4, 'Remember to prioritize kitchen equipment safety checks.', 4),
(5, 'Excellent assistance with meal preparation.', 5),
(6, 'Keep up the good work serving meals to everyone!', 6),
(7, 'Tables are looking clean and sanitized, good job!', 7),
(8, 'Make sure condiments and utensils are fully stocked.', 8),
(9, 'Let''s plan a special dinner menu for next week.', 9),
(10, 'Fantastic job organizing the recent dining hall event!', 10),
(11, 'Handle customer inquiries promptly and with a smile.', 11),
(12, 'Monitor food temperature closely for safety.', 12),
(13, 'Well done on training the new dining hall employees.', 13),
(14, 'Let''s brainstorm more sustainability initiatives.', 14),
(15, 'Keep the menu boards updated with fresh specials.', 15),
(16, 'Safety inspections are crucial - keep it up!', 16),
(17, 'Themed dining nights are a hit - keep planning!', 17),
(18, 'Efficient cashier transactions are key - nice work!', 18),
(19, 'Coordinate with local vendors for the freshest produce.', 19),
(20, 'Social media promotion is boosting our visibility!', 20),
(21, 'Consult nutritionists for healthy menu options.', 21),
(22, 'Collect diner feedback regularly for improvement.', 22),
(23, 'Attendance at staff meetings is appreciated.', 23),
(24, 'Ensure staff shifts and breaks are scheduled properly.', 24),
(25, 'Employee recognition programs boost morale, thanks!', 25),
(26, 'Team-building activities are fostering a great atmosphere.', 26),
(27, 'Performance evaluations help us strive for excellence.', 27),
(28, 'Implement more strategies to reduce food waste.', 28),
(29, 'Building partnerships with local businesses is crucial.', 29),
(30, 'Catering services for campus events are going well.', 30);

#Insert issues into the Issues table

INSERT INTO Issues (IssueID, Description, IssueStatus, AssignmentID) VALUES
(1, 'Low inventory of milk in the fridge', 'Open', 1),
(2, 'Broken toaster in the breakfast station', 'Open', 2),
(3, 'Spilled food in aisle 3 needs cleaning', 'Open', 3),
(4, 'Burned-out light bulb above cashier counter', 'Open', 4),
(5, 'Complaints about cold pasta in the lunch buffet', 'Open', 5),
(6, 'Insufficient napkins at dining tables', 'Open', 6),
(7, 'Fridge temperature needs adjustment', 'Open', 7),
(8, 'Out of stock on salad ingredients', 'Open', 8),
(9, 'Customer reported a loose chair in dining area', 'Open', 9),
(10, 'Issue with the coffee machine not dispensing properly', 'Open', 10),
(11, 'Request for gluten-free options from multiple diners', 'Open', 11),
(12, 'Dishwasher malfunction causing delays in dishwashing', 'Open', 12),
(13, 'Spilled sauce on the kitchen floor requires cleanup', 'Open', 13),
(14, 'Clogged drain in the dishwashing area', 'Open', 14),
(15, 'Customer complaint about overcooked burgers', 'Open', 15),
(16, 'Request for vegan dessert options', 'Open', 16),
(17, 'Plumbing issue causing water leakage in the pantry', 'Open', 17),
(18, 'Issue with the ventilation system in the kitchen', 'Open', 18),
(19, 'Report of a broken chair at the dining hall entrance', 'Open', 19),
(20, 'Customer complaint about noisy kitchen ventilation', 'Open', 20),
(21, 'Request for more vegetarian options on the menu', 'Open', 21),
(22, 'Report of a slippery floor near the salad bar', 'Open', 22),
(23, 'Issue with the ice machine not producing ice', 'Open', 23),
(24, 'Customer reported a moldy smell near the restroom', 'Open', 24),
(25, 'Request for allergen information for menu items', 'Open', 25),
(26, 'Report of a leaking faucet in the kitchen', 'Open', 26),
(27, 'Customer complaint about slow service during peak hours', 'Open', 27),
(28, 'Request for more sustainable packaging for takeout', 'Open', 28),
(29, 'Report of a broken chair at the outdoor dining area', 'Open', 29),
(30, 'Issue with the POS system not processing payments', 'Open', 30);

